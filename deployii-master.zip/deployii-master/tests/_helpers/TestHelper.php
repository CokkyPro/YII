<?php
namespace Codeception\Module;

class TestHelper extends \Codeception\Module
{
    // here you can define custom methods for TestGuy
}
