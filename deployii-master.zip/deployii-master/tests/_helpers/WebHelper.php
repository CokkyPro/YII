<?php
namespace Codeception\Module;

class WebHelper extends \Codeception\Module
{
    // here you can define custom methods for WebGuy
}
