<?php

new yii\web\Application(require(__DIR__ . '/_config.php'));
