#!/usr/bin/env php
<?php
/**
 * DeploYii - PHAR stub file
 *
 * @link      https://github.com/giovdk21/deployii
 * @copyright Copyright (c) 2014 Giovanni Derks
 * @license   https://github.com/giovdk21/deployii/blob/master/LICENSE
 */

Phar::mapPhar();
//include 'phar://deployii.phar/deployii';
include 'phar://deployii.phar/deployii';
__HALT_COMPILER();