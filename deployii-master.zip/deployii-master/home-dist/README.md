
This directory contains the default content of the DeploYii home directory which is located
inside the user home folder or where specified by the DEPLOYII_HOME environment variable.

On the first run, the home directory is created by copying the current folder to the DeploYii home path.