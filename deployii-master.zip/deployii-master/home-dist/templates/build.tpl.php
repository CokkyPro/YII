<?php

use yii\helpers\Console;

return [

    'deployiiVersion' => '{{deployiiVersion}}',

    'require'         => [],

    'params'          => [
    ],

    'targets'         => [

        'default' => [
            ['out', 'Hello world!'],
        ],

    ],

];
