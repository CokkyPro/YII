
Note: this folder is temporary; the content will be moved to database.