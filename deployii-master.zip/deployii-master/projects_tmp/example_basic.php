<?php

// TODO: move to database (see README)

return [
    'id'         => 'example_basic',
    'title'      => 'Basic Example project',
    'repo'       => 'https://github.com/giovdk21/deployii-examples.git',
    'branch'     => false, // use the default branch
    'rootFolder' => 'basicExample',
];